package com.ajc.model


case class Food(name: String)
