package com.ajc.base


trait Time{
     def getTime():String
}
