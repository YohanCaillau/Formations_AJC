package com.ajc.base

import com.ajc.model.Food

trait Cooker{
     def cook(what: String) :Food
}
