package com.ajc.base


trait RecipeFinder {
    def findRecipe(dish: String):String
}
